import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContratosPage } from './contratos.page'; // ← Este nome deve bater

const routes: Routes = [
  {
    path: '',
    component: ContratosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContratosPageRoutingModule {}