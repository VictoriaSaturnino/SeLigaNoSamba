import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'contratos',
    loadChildren: () => import('./contratos/contratos.module').then( m => m.ContratosPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'agenda-visitante',
    loadChildren: () => import('./agenda-visitante/agenda-visitante.module').then( m => m.AgendaVisitantePageModule)
  },
  {
    path: 'biografia',
    loadChildren: () => import('./biografia/biografia.module').then( m => m.BiografiaPageModule)
  },
  {
    path: 'perfil-contratante',
    loadChildren: () => import('./perfil-contratante/perfil-contratante.module').then( m => m.PerfilContratantePageModule)
  },
  {
    path: 'perfil-produtor',
    loadChildren: () => import('./perfil-produtor/perfil-produtor.module').then( m => m.PerfilProdutorPageModule)
  },
  {
    path: 'cadastro',
    loadChildren: () => import('./cadastro/cadastro.module').then( m => m.CadastroPageModule)
  },
  {
    path: 'simulacao-contratante',
    loadChildren: () => import('./simulacao-contratante/simulacao-contratante.module').then( m => m.SimulacaoContratantePageModule)
  },
  {
    path: 'sair',
    loadChildren: () => import('./sair/sair.module').then( m => m.SairPageModule)
  },
  {
    path: 'contratos-produtor',
    loadChildren: () => import('./contratos-produtor/contratos-produtor.module').then( m => m.ContratosProdutorPageModule)
  },
  {
    path: 'agenda-produtor',
    loadChildren: () => import('./agenda-produtor/agenda-produtor.module').then( m => m.AgendaProdutorPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
