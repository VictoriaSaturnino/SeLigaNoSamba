import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OrcamentosProdutorPage } from './orcamentos-produtor.page';

describe('OrcamentosProdutorPage', () => {
  let component: OrcamentosProdutorPage;
  let fixture: ComponentFixture<OrcamentosProdutorPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(OrcamentosProdutorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
