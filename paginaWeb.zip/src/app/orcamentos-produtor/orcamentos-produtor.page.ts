import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-orcamentos-produtor',
  templateUrl: './orcamentos-produtor.page.html',
  styleUrls: ['./orcamentos-produtor.page.scss'],
  standalone: false
})
export class OrcamentosProdutorPage implements OnInit {

  contratos: any[] = [];
  private contratosApi = 'http://localhost:8080/seliganosamba/api/contratos';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.loadContratos();
  }

  private loadContratos() {
    this.http.get<any[]>(this.contratosApi).subscribe({
      next: (list) => {
        // Filter to show only contracts where BOTH parties signed
        this.contratos = (list || [])
          .filter(c => {
            const produtorSigned = c.assinaturaProdutor === true || c.assinaturaProdutor === 'true';
            const contratanteSigned = c.assinaturaContratante === true || c.assinaturaContratante === 'true';
            return produtorSigned && contratanteSigned;
          })
          .map(c => {
            // Usa o valor que vem do backend (não gera mais client-side)
            return c;
          });
      },
      error: (err) => {
        console.error('Erro carregando contratos', err);
        this.contratos = [];
      }
    });
  }

  private generateValor(c: any) {
    const base = 150.0;
    const perGuest = 20.0;
    const qty = (c?.agendamento?.quantidadeConvidados) || (c?.agendamento?.quantidadeConvidados === 0 ? 0 : 50);
    const randomPart = Math.random() * 500.0;
    let valor = base + (qty * perGuest) + randomPart;
    return Math.round(valor * 100) / 100;
  }

  gerarPdf(c: any) {
    const html = this.buildPrintableHtml(c);
    const win = window.open('', '_blank');
    if (!win) {
      alert('Pop-up bloqueado. Permita pop-ups para gerar o PDF.');
      return;
    }
    win.document.write(html);
    win.document.close();
    setTimeout(() => { win.print(); }, 250);
  }

  private buildPrintableHtml(c: any) {
    const ag = c.agendamento || {};
    const data = ag.dataEvento ? (ag.dataEvento + '').substring(0, 10) : '';
    const horario = ag.horario || '';
    const nomeEvento = ag.nomeEvento || '';
    const qtd = ag.quantidadeConvidados || '';
    const rua = ag.rua || '';
    const numero = ag.numero || '';
    const bairro = ag.bairro || '';
    const cidade = ag.cidade || '';
    const estado = ag.estado || '';
    const sonorizacao = ag.sonorizacao ? 'Sim' : 'Não';
    const tipo = ag.tipoEvento || '';
    const valor = c.valor || 0;
    
    console.log('DEBUG - Contrato:', c);
    console.log('DEBUG - Agendamento:', ag);
    console.log('DEBUG - Dados extraídos:', { data, horario, nomeEvento, qtd, rua, numero, bairro, cidade, estado, sonorizacao, tipo, valor });

    return `
      <html>
        <head>
          <title>Orçamento Final - ${nomeEvento}</title>
          <meta charset="UTF-8">
          <style>
            body { font-family: Arial, sans-serif; padding: 30px; line-height: 1.6; }
            h1 { color:#333; text-align:center; margin-bottom: 30px; }
            h2 { color:#555; border-bottom: 2px solid #d45827; padding-bottom: 10px; }
            .section { margin: 25px 0; padding: 15px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; }
            .field { margin-bottom: 12px; }
            .label { font-weight:700; color: #333; }
            .valor { font-size: 32px; color: #d45827; font-weight: bold; text-align: center; margin: 30px 0; padding: 25px; background: #fff8f0; border: 2px solid #d45827; border-radius: 8px; }
            .assinaturas { margin-top: 50px; padding-top: 30px; border-top: 2px solid #333; }
            .assinatura-box { display: inline-block; width: 45%; text-align: center; margin: 20px 2%; vertical-align: top; }
            .check { color: green; font-size: 28px; margin-bottom: 10px; font-weight: bold; }
            .footer { margin-top: 40px; text-align: center; color: #999; font-size: 12px; border-top: 1px solid #ddd; padding-top: 20px; }
            .status-assinado { color: green; font-weight: bold; font-size: 14px; }
          </style>
        </head>
        <body>
          <h1>ORÇAMENTO FINAL ASSINADO</h1>
          
          <div class="section">
            <h2>Dados do Evento</h2>
            <div class="field"><span class="label">Evento:</span> ${nomeEvento}</div>
            <div class="field"><span class="label">Data:</span> ${data}</div>
            <div class="field"><span class="label">Horário:</span> ${horario}</div>
            <div class="field"><span class="label">Tipo de evento:</span> ${tipo}</div>
            <div class="field"><span class="label">Quantidade de convidados:</span> ${qtd}</div>
          </div>

          <div class="section">
            <h2>Local do Evento</h2>
            <div class="field"><span class="label">Rua:</span> ${rua}</div>
            <div class="field"><span class="label">Número:</span> ${numero}</div>
            <div class="field"><span class="label">Bairro:</span> ${bairro}</div>
            <div class="field"><span class="label">Cidade:</span> ${cidade}</div>
            <div class="field"><span class="label">Estado:</span> ${estado}</div>
          </div>

          <div class="section">
            <h2>Serviços Contratados</h2>
            <div class="field"><span class="label">Sonorização:</span> ${sonorizacao}</div>
          </div>

          <div class="valor">
            VALOR TOTAL: R$ ${valor.toFixed(2)}
          </div>

          <div class="assinaturas">
            <h2>Status de Assinatura</h2>
            <div class="assinatura-box">
              <div class="check">✓</div>
              <div><strong>CONTRATANTE</strong></div>
              <div class="status-assinado">ASSINADO</div>
            </div>
            <div class="assinatura-box">
              <div class="check">✓</div>
              <div><strong>PRODUTOR</strong></div>
              <div class="status-assinado">ASSINADO</div>
            </div>
          </div>

          <div class="footer">
            <p>Documento gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
            <p>Este é um orçamento final e assinado por ambas as partes.</p>
          </div>
        </body>
      </html>
    `;
  }

}
