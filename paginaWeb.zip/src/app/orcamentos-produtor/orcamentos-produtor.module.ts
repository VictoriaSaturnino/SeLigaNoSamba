import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { IonicModule } from '@ionic/angular';

import { OrcamentosProdutorPageRoutingModule } from './orcamentos-produtor-routing.module';

import { OrcamentosProdutorPage } from './orcamentos-produtor.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    OrcamentosProdutorPageRoutingModule
  ],
  declarations: [OrcamentosProdutorPage]
})
export class OrcamentosProdutorPageModule {}
