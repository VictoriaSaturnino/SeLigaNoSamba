import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PerfilProdutorPage } from './perfil-produtor.page';

const routes: Routes = [
  {
    path: '',
    component: PerfilProdutorPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PerfilProdutorPageRoutingModule {}
