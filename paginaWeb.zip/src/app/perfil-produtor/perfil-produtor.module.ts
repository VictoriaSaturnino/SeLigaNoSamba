import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';

import { PerfilProdutorPageRoutingModule } from './perfil-produtor-routing.module';

import { PerfilProdutorPage } from './perfil-produtor.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    PerfilProdutorPageRoutingModule
  ],
  declarations: [PerfilProdutorPage]
})
export class PerfilProdutorPageModule {}
