import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-perfil-produtor',
  templateUrl: './perfil-produtor.page.html',
  styleUrls: ['./perfil-produtor.page.scss'],
  standalone: false, 
})
export class PerfilProdutorPage implements OnInit {
  contratos: any[] = [];
  usuario: any = { nome: '', email: '', telefone: '', dtNascimento: '', senha: '' };
  saving = false;
  private apiAgendamento = 'http://localhost:8080/seliganosamba/api/agendamentos';
  private apiUsuario = 'http://localhost:8080/seliganosamba/api/usuarios';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.loadContratosPendentes();
    this.loadUsuario();
  }

  private loadContratosPendentes() {
    this.http.get<any[]>(this.apiAgendamento).subscribe({
      next: (list) => {
        this.contratos = (list || []).filter(a => a.aprovado === false || a.aprovado === 0 || a.aprovado === 'false');
      },
      error: (err) => {
        console.error('Erro ao carregar agendamentos', err);
        this.contratos = [];
      }
    });
  }

  private loadUsuario() {
    const raw = localStorage.getItem('user');
    if (!raw) return;
    try {
      const u = JSON.parse(raw);
      const id = u.id || u.idUsuario;
      if (!id) return;
      this.http.get<any>(`${this.apiUsuario}/${id}`).subscribe({
        next: (resp) => {
          this.usuario = {
            idUsuario: resp.idUsuario,
            nome: resp.nome,
            email: resp.email,
            telefone: resp.telefone,
            dtNascimento: resp.dtNascimento ? resp.dtNascimento.toString() : '',
            senha: resp.senha || ''
          };
        },
        error: (err) => {
          console.error('Erro ao carregar usuário', err);
        }
      });
    } catch (e) {
      console.error('Erro ao ler usuário do localStorage');
    }
  }

  salvarDados() {
    if (!this.usuario?.idUsuario) return;
    this.saving = true;
    const payload = {
      nome: this.usuario.nome,
      email: this.usuario.email,
      telefone: this.usuario.telefone,
      dtNascimento: this.usuario.dtNascimento,
      funcao: 'produtor',
      senha: this.usuario.senha || ''
    };
    this.http.put(`${this.apiUsuario}/${this.usuario.idUsuario}`, payload).subscribe({
      next: () => {
        alert('Dados atualizados com sucesso.');
      },
      error: (err) => {
        console.error('Erro ao salvar dados', err);
        alert('Erro ao salvar dados.');
      }
    }).add(() => {
      this.saving = false;
    });
  }

  getDay(dateStr: string) {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.getDate();
    } catch (e) { return '' }
  }

  getMonthShort(dateStr: string) {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleString('pt-BR', { month: 'short' }).toUpperCase();
    } catch (e) { return '' }
  }

}
