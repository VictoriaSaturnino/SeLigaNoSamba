import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biografia',
  templateUrl: './biografia.page.html',
  styleUrls: ['./biografia.page.scss'],
  standalone: false,
})
export class BiografiaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
