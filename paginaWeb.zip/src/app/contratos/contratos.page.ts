import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contratos',
  templateUrl: './contratos.page.html',
  styleUrls: ['./contratos.page.scss'],
  standalone: false,
})
export class ContratosPage implements OnInit {

  contratos: any[] = [];
  private contratosApi = 'http://localhost:8080/seliganosamba/api/contratos';
  private agendamentoApi = 'http://localhost:8080/seliganosamba/api/agendamentos';
  private usuarioApi = 'http://localhost:8080/seliganosamba/api/usuarios';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.loadContratos();
  }

  private loadContratos() {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
      console.error('Usuário não encontrado no localStorage');
      this.contratos = [];
      return;
    }
    const user = JSON.parse(userStr);
    const idUsuario = user.id || user.idUsuario;

    // Load contratos and filter by logged user (contratante)
    this.http.get<any[]>(this.contratosApi).subscribe({
      next: (contratosList) => {
        const mapByAg = new Map<number, any>();
        (contratosList || []).forEach(c => {
          const aid = c.idAgendamento || c.agendamento?.idAgendamento || c.agendamento?.id;
          if (aid) mapByAg.set(Number(aid), c);
        });

        this.http.get<any[]>(this.agendamentoApi).subscribe({
          next: (list) => {
            // Filter agendamentos by logged user (idUsuario)
            const userAgendamentos = (list || []).filter(a => {
              const agUserId = a.idUsuario || a.usuario?.idUsuario || a.usuario?.id;
              return agUserId && Number(agUserId) === Number(idUsuario);
            });

            this.contratos = userAgendamentos.map(a => {
              const aid = a.idAgendamento || a.id;
              const contrato = aid ? mapByAg.get(Number(aid)) : null;
              if (contrato) {
                a.contrato = contrato;
                a.assinaturaContratante = contrato.assinaturaContratante === true || contrato.assinaturaContratante === 'true';
                a.assinaturaProdutor = contrato.assinaturaProdutor === true || contrato.assinaturaProdutor === 'true';
              }
              return a;
            }).filter(a => {
              // Only show if contrato exists and assinaturaContratante is NOT true yet
              if (a.contrato) {
                return a.assinaturaContratante !== true;
              }
              return false; // no contrato means nothing to sign
            });
          },
          error: (err) => {
            console.error('Erro carregando agendamentos', err);
            this.contratos = [];
          }
        });
      },
      error: (err) => {
        console.error('Erro carregando contratos', err);
        this.contratos = [];
      }
    });
  }

  signContratante(ag: any) {
    if (!ag.contrato || ag.assinaturaContratante) return;
    const contratoId = ag.contrato.idContrato;
    const updated = { ...ag.contrato, assinaturaContratante: true };
    this.http.put(`${this.contratosApi}/${contratoId}`, updated).subscribe({
      next: () => {
        ag.assinaturaContratante = true;
        // Remove from list since contratante signed
        this.removeContratoFromList(ag);
      },
      error: (e) => console.error('Erro ao assinar contrato', e)
    });
  }

  private removeContratoFromList(ag: any) {
    const idx = this.contratos.findIndex(x => {
      const xId = x.idAgendamento || x.id;
      const agId = ag.idAgendamento || ag.id;
      return xId && agId && Number(xId) === Number(agId);
    });
    if (idx >= 0) this.contratos.splice(idx, 1);
  }

  async gerarPdf(ag: any) {
    let produtorNome = ag.usuario && ag.usuario.nome ? ag.usuario.nome : null;
    const idUsuario = ag.idUsuario || (ag.usuario && ag.usuario.idUsuario) || (ag.usuario && ag.usuario.id);
    if (!produtorNome && idUsuario) {
      try {
        const u: any = await this.http.get<any>(`${this.usuarioApi}/${idUsuario}`).toPromise();
        produtorNome = u?.nome;
      } catch (e) {
        console.warn('Não foi possível obter nome do produtor', e);
      }
    }

    const html = this.buildPrintableHtml(ag, produtorNome);
    const win = window.open('', '_blank');
    if (!win) {
      alert('Pop-up bloqueado. Permita pop-ups para gerar o PDF.');
      return;
    }
    win.document.write(html);
    win.document.close();
    setTimeout(() => { win.print(); }, 250);
  }

  private buildPrintableHtml(ag: any, produtorNome?: string) {
    const data = (ag.dataEvento || '').toString().substring(0,10);
    const horario = ag.horario || '';
    const nomeEvento = ag.nomeEvento || '';
    const qtd = ag.quantidadeConvidados || '';
    const rua = ag.rua || '';
    const numero = ag.numero || '';
    const bairro = ag.bairro || '';
    const cidade = ag.cidade || '';
    const estado = ag.estado || '';
    const sonorizacao = ag.sonorizacao ? 'Sim' : 'Não';
    const tipo = ag.tipoEvento || '';
    const produtor = produtorNome || '—';

    return `
      <html>
        <head>
          <title>Contrato - ${nomeEvento}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color:#333 }
            .field { margin-bottom: 10px; }
            .label { font-weight:700 }
          </style>
        </head>
        <body>
          <h1>Contrato / Pré-Orçamento</h1>
          <div class="field"><span class="label">Evento:</span> ${nomeEvento}</div>
          <div class="field"><span class="label">Produtor:</span> ${produtor}</div>
          <div class="field"><span class="label">Data:</span> ${data}</div>
          <div class="field"><span class="label">Horário:</span> ${horario}</div>
          <div class="field"><span class="label">Quantidade convidados:</span> ${qtd}</div>
          <div class="field"><span class="label">Rua / Número:</span> ${rua} / ${numero}</div>
          <div class="field"><span class="label">Bairro:</span> ${bairro}</div>
          <div class="field"><span class="label">Cidade / Estado:</span> ${cidade} / ${estado}</div>
          <div class="field"><span class="label">Sonorização:</span> ${sonorizacao}</div>
          <div class="field"><span class="label">Tipo de evento:</span> ${tipo}</div>
        </body>
      </html>
    `;
  }

}
