import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AgendaProdutorPageRoutingModule } from './agenda-produtor-routing.module';

import { AgendaProdutorPage } from './agenda-produtor.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AgendaProdutorPageRoutingModule
  ],
  declarations: [AgendaProdutorPage]
})
export class AgendaProdutorPageModule {}
