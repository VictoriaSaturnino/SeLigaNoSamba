import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AgendaProdutorPage } from './agenda-produtor.page';

describe('AgendaProdutorPage', () => {
  let component: AgendaProdutorPage;
  let fixture: ComponentFixture<AgendaProdutorPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AgendaProdutorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
