import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-agenda-produtor',
  templateUrl: './agenda-produtor.page.html',
  styleUrls: ['./agenda-produtor.page.scss'],
  standalone: false,
})
export class AgendaProdutorPage implements OnInit {

  agendamentos: any[] = [];
  loading = false;
  error: string | null = null;
  selected: any = null;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading = true;
    this.error = null;

    this.http.get<any[]>('http://localhost:8080/seliganosamba/api/agendamentos').subscribe({
      next: (data) => {
        const raw = (data || []);

        // Filtra apenas agendamentos aprovados (não importa se públicos ou privados)
        const aprovados = raw.filter((a: any) => a.aprovado === true);

        // Ordena por data do evento
        const parseLocalDate = (input: any): Date | null => {
          if (input == null) return null;
          if (typeof input === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(input)) {
            const [y, m, d] = input.split('-').map(Number);
            return new Date(y, m - 1, d);
          }
          try {
            const d = new Date(input);
            if (isNaN(d.getTime())) return null;
            return d;
          } catch (e) { return null; }
        };

        const dateForSort = (a: any) => {
          const d = parseLocalDate(a?.dataEvento);
          return d ? d.getTime() : Number.POSITIVE_INFINITY;
        };

        aprovados.sort((a: any, b: any) => {
          const ta = dateForSort(a);
          const tb = dateForSort(b);
          return ta - tb;
        });

        this.agendamentos = aprovados;
        this.loading = false;
      },
      error: (err) => {
        console.error('Erro carregando agendamentos:', err);
        this.error = 'Erro ao carregar agendamentos';
        this.loading = false;
      }
    });
  }

  getMonth(data: string): string {
    if (!data) return '';
    const months = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
    const date = new Date(data + 'T00:00:00');
    return months[date.getMonth()];
  }

  getDay(data: string): string {
    if (!data) return '';
    const date = new Date(data + 'T00:00:00');
    return date.getDate().toString();
  }

  openDetails(agendamento: any) {
    this.selected = agendamento;
  }

  closeDetails() {
    this.selected = null;
  }

}
