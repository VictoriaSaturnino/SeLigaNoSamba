import { TestBed } from '@angular/core/testing';

import { AgendaVisitante } from './agenda-visitante';

describe('AgendaVisitante', () => {
  let service: AgendaVisitante;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgendaVisitante);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
