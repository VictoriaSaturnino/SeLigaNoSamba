import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContratosProdutorPage } from './contratos-produtor.page';

describe('ContratosProdutorPage', () => {
  let component: ContratosProdutorPage;
  let fixture: ComponentFixture<ContratosProdutorPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ContratosProdutorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
