import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ContratosProdutorPageRoutingModule } from './contratos-produtor-routing.module';

import { ContratosProdutorPage } from './contratos-produtor.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ContratosProdutorPageRoutingModule
  ],
  declarations: [ContratosProdutorPage]
})
export class ContratosProdutorPageModule {}
