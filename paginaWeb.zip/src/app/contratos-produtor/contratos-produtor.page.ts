import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contratos-produtor',
  templateUrl: './contratos-produtor.page.html',
  styleUrls: ['./contratos-produtor.page.scss'],
  standalone: false
})
export class ContratosProdutorPage implements OnInit {

  contratos: any[] = [];
  private agendamentoApi = 'http://localhost:8080/seliganosamba/api/agendamentos';
  private usuarioApi = 'http://localhost:8080/seliganosamba/api/usuarios';
  private contratosApi = 'http://localhost:8080/seliganosamba/api/contratos';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.loadPendentes();
  }

  private loadPendentes() {
    // First load contratos so we can attach assinatura info to agendamentos
    this.http.get<any[]>(this.contratosApi).subscribe({
      next: (contratosList) => {
        const mapByAg = new Map<number, any>();
        (contratosList || []).forEach(c => {
          const aid = c.idAgendamento || c.agendamento?.idAgendamento || c.agendamento?.id;
          if (aid) mapByAg.set(Number(aid), c);
        });

        this.http.get<any[]>(this.agendamentoApi).subscribe({
          next: (list) => {
            const all = (list || []);
            // attach contrato info and filter: show if not fully signed and not approved
            this.contratos = all.map(a => {
              const aid = a.idAgendamento || a.id;
              const contrato = aid ? mapByAg.get(Number(aid)) : null;
              if (contrato) {
                a.contrato = contrato;
                a.assinaturaContratante = contrato.assinaturaContratante === true || contrato.assinaturaContratante === 'true';
                a.assinaturaProdutor = contrato.assinaturaProdutor === true || contrato.assinaturaProdutor === 'true';
              }
              return a;
            }).filter(a => {
              const aprovado = a.aprovado === true || a.aprovado === 'true' || a.aprovado === 1;
              const contrato = a.contrato;
              // If there is a contrato, keep showing it until BOTH parties sign
              if (contrato) {
                const bothSigned = (a.assinaturaContratante === true) && (a.assinaturaProdutor === true);
                return !bothSigned; // show while not both signed
              }
              // otherwise, show when not approved
              return !aprovado;
            });
          },
          error: (err) => {
            console.error('Erro carregando agendamentos', err);
            this.contratos = [];
          }
        });
      },
      error: (err) => {
        console.error('Erro carregando contratos', err);
        // fallback to just loading agendamentos without contrato info
        this.http.get<any[]>(this.agendamentoApi).subscribe({
          next: (list) => {
            this.contratos = (list || []).filter(a => a.aprovado === false || a.aprovado === 0 || a.aprovado === 'false');
          },
          error: (err2) => {
            console.error('Erro carregando agendamentos', err2);
            this.contratos = [];
          }
        });
      }
    });
  }

  approve(ag: any) {
    const id = ag.idAgendamento || ag.id;
    if (!id) return;
    this.http.get<any>(`${this.agendamentoApi}/${id}`).subscribe({
      next: (full) => {
        full.aprovado = true;
        this.http.put(`${this.agendamentoApi}/${id}`, full).subscribe({
          next: () => this.loadPendentes(),
          error: (e) => console.error('Erro aprovando', e)
        });
      },
      error: (e) => console.error('Erro ao obter agendamento', e)
    });
  }

  rejeitar(ag: any) {
    const id = ag.idAgendamento || ag.id;
    if (!id) return;
    this.http.delete(`${this.agendamentoApi}/${id}`).subscribe({
      next: () => this.loadPendentes(),
      error: (e) => console.error('Erro removendo agendamento', e)
    });
  }

  async gerarPdf(ag: any) {
    let contratanteNome = ag.usuario && (ag.usuario.nome || ag.usuario.nome) ? ag.usuario.nome : null;
    const idUsuario = ag.idUsuario || (ag.usuario && ag.usuario.idUsuario) || (ag.usuario && ag.usuario.id);
    if (!contratanteNome && idUsuario) {
      try {
        const u: any = await this.http.get<any>(`${this.usuarioApi}/${idUsuario}`).toPromise();
        contratanteNome = u?.nome;
      } catch (e) {
        console.warn('Não foi possível obter nome do contratante', e);
      }
    }

    const html = this.buildPrintableHtml(ag, contratanteNome);
    const win = window.open('', '_blank');
    if (!win) {
      alert('Pop-up bloqueado. Permita pop-ups para gerar o PDF.');
      return;
    }
    win.document.write(html);
    win.document.close();
    setTimeout(() => { win.print(); }, 250);
  }

  private buildPrintableHtml(ag: any, contratanteNome?: string) {
    const data = (ag.dataEvento || '').toString().substring(0,10);
    const horario = ag.horario || '';
    const nomeEvento = ag.nomeEvento || '';
    const qtd = ag.quantidadeConvidados || '';
    const rua = ag.rua || '';
    const numero = ag.numero || '';
    const bairro = ag.bairro || '';
    const cidade = ag.cidade || '';
    const estado = ag.estado || '';
    const sonorizacao = ag.sonorizacao ? 'Sim' : 'Não';
    const tipo = ag.tipoEvento || '';
    const contratante = contratanteNome || '—';

    return `
      <html>
        <head>
          <title>Contrato - ${nomeEvento}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color:#333 }
            .field { margin-bottom: 10px; }
            .label { font-weight:700 }
          </style>
        </head>
        <body>
          <h1>Contrato / Pré-Orçamento</h1>
          <div class="field"><span class="label">Evento:</span> ${nomeEvento}</div>
          <div class="field"><span class="label">Contratante:</span> ${contratante}</div>
          <div class="field"><span class="label">Data:</span> ${data}</div>
          <div class="field"><span class="label">Horário:</span> ${horario}</div>
          <div class="field"><span class="label">Quantidade convidados:</span> ${qtd}</div>
          <div class="field"><span class="label">Rua / Número:</span> ${rua} / ${numero}</div>
          <div class="field"><span class="label">Bairro:</span> ${bairro}</div>
          <div class="field"><span class="label">Cidade / Estado:</span> ${cidade} / ${estado}</div>
          <div class="field"><span class="label">Sonorização:</span> ${sonorizacao}</div>
          <div class="field"><span class="label">Tipo de evento:</span> ${tipo}</div>
        </body>
      </html>
    `;
  }

}
