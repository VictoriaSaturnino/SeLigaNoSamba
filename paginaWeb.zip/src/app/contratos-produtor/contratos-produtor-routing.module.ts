import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ContratosProdutorPage } from './contratos-produtor.page';

const routes: Routes = [
  {
    path: '',
    component: ContratosProdutorPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContratosProdutorPageRoutingModule {}
