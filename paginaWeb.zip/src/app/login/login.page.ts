import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage implements OnInit {

  email: string = '';
  senha: string = '';
  loading = false;
  error: string | null = null;

  private apiUrl = 'http://localhost:8080/seliganosamba/api/usuarios';

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit() {}

  login() {
    this.error = null;
    if (!this.email || !this.senha) {
      this.error = 'Preencha email e senha';
      return;
    }
    this.loading = true;
    this.http.get<any[]>(this.apiUrl).subscribe({
      next: (users) => {
        const email = this.email.trim().toLowerCase();
        const senha = this.senha;
        const found = (users || []).find(u => (u.email || '').toString().trim().toLowerCase() === email && (u.senha || '').toString() === senha);
        if (!found) {
          this.error = 'Credenciais inválidas';
          this.loading = false;
          return;
        }

        // store minimal user info locally
        localStorage.setItem('user', JSON.stringify({ id: found.idUsuario || found.id, nome: found.nome, funcao: found.funcao }));

        // Redirect based on funcao
        const func = (found.funcao || '').toString().trim().toLowerCase();
        if (func === 'produtor') {
          this.router.navigate(['/perfil-produtor']);
        } else if (func === 'contratante') {
          this.router.navigate(['/perfil-contratante']);
        } else {
          // default to home
          this.router.navigate(['/home']);
        }
      },
      error: (err) => {
        console.error('Erro ao buscar usuários', err);
        this.error = 'Erro de conexão com a API';
        this.loading = false;
      }
    });
  }

}
