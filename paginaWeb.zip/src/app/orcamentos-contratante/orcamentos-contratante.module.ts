import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OrcamentosContratantePageRoutingModule } from './orcamentos-contratante-routing.module';

import { OrcamentosContratantePage } from './orcamentos-contratante.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OrcamentosContratantePageRoutingModule
  ],
  declarations: [OrcamentosContratantePage]
})
export class OrcamentosContratantePageModule {}
