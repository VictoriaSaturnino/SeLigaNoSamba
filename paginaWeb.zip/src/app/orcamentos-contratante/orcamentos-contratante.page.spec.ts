import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OrcamentosContratantePage } from './orcamentos-contratante.page';

describe('OrcamentosContratantePage', () => {
  let component: OrcamentosContratantePage;
  let fixture: ComponentFixture<OrcamentosContratantePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(OrcamentosContratantePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
