import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OrcamentosContratantePage } from './orcamentos-contratante.page';

const routes: Routes = [
  {
    path: '',
    component: OrcamentosContratantePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrcamentosContratantePageRoutingModule {}
