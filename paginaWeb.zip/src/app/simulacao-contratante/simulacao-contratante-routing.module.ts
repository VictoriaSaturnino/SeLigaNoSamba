import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SimulacaoContratantePage } from './simulacao-contratante.page';

const routes: Routes = [
  {
    path: '',
    component: SimulacaoContratantePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SimulacaoContratantePageRoutingModule {}
