import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SimulacaoContratantePage } from './simulacao-contratante.page';

describe('SimulacaoContratantePage', () => {
  let component: SimulacaoContratantePage;
  let fixture: ComponentFixture<SimulacaoContratantePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SimulacaoContratantePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
