import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-simulacao-contratante',
  templateUrl: './simulacao-contratante.page.html',
  styleUrls: ['./simulacao-contratante.page.scss'],
  standalone: false,
})
export class SimulacaoContratantePage implements OnInit {

  form: any = {
    nomeEvento: '',
    quantidadeConvidados: 0,
    tipoEvento: '',
    isPublico: true,
    rua: '',
    numero: '',
    bairro: '',
    cidade: '',
    estado: '',
    dataEvento: '',
    horario: '',
    sonorizacao: false
  };

  private agendamentoApi = 'http://localhost:8080/seliganosamba/api/agendamentos';

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit() {
  }

  enviarSimulacao() {
    // get logged-in user from localStorage
    const raw = localStorage.getItem('user');
    if (!raw) {
      alert('Usuário não autenticado. Faça login.');
      this.router.navigate(['/login']);
      return;
    }

    const localUser = JSON.parse(raw);
    const idUsuario = localUser.id || localUser.idUsuario || null;
    if (!idUsuario) {
      alert('ID do usuário não encontrado. Faça login novamente.');
      this.router.navigate(['/login']);
      return;
    }

    // Try to fetch full usuario from API to include in payload
    this.http.get<any>(`http://localhost:8080/seliganosamba/api/usuarios/${idUsuario}`).subscribe({
      next: (fullUser) => {
        this.postAgendamento(fullUser, idUsuario);
      },
      error: () => {
        // if fetch fails, still proceed with minimal user info
        const fallbackUser = { idUsuario: idUsuario, nome: localUser.nome };
        this.postAgendamento(fallbackUser, idUsuario);
      }
    });
  }

  private postAgendamento(usuarioObj: any, idUsuario: any) {
    // generate an idAgendamento client-side (timestamp) as requested
    const generatedId = Date.now();

    // prepare payload
    const payload: any = {
      idAgendamento: generatedId,
      idUsuario: idUsuario,
      usuario: usuarioObj,
      nomeEvento: this.form.nomeEvento || 'Simulação',
      quantidadeConvidados: Number(this.form.quantidadeConvidados) || 0,
      rua: this.form.rua || '',
      numero: this.form.numero || '',
      bairro: this.form.bairro || '',
      cidade: this.form.cidade || '',
      estado: this.form.estado || '',
      dataEvento: this.form.dataEvento || null,
      sonorizacao: this.form.sonorizacao === 'true' || this.form.sonorizacao === true,
      tipoEvento: this.form.tipoEvento || '',
      // visibilidade: isPublico (true => pública, false => privada)
      isPublico: this.form.isPublico === true || this.form.isPublico === 'true',
      // omit orcamento so backend can handle as null/default
      horario: this.form.horario || null,
      aprovado: false
    };

    this.http.post(this.agendamentoApi, payload).subscribe({
      next: (resp) => {
        alert('Pré-orçamento enviado (simulação) com sucesso.');
      },
      error: (err) => {
        console.error('Erro ao enviar agendamento', err);
        alert('Erro ao enviar pré-orçamento. Veja console.');
      }
    });
  }

}
