import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SimulacaoContratantePageRoutingModule } from './simulacao-contratante-routing.module';

import { SimulacaoContratantePage } from './simulacao-contratante.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SimulacaoContratantePageRoutingModule
  ],
  declarations: [SimulacaoContratantePage]
})
export class SimulacaoContratantePageModule {}
