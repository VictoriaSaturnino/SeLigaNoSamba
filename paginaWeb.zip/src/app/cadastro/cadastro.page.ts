import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.page.html',
  styleUrls: ['./cadastro.page.scss'],
  standalone: false,
})
export class CadastroPage {

  usuario = {
    nome: '',
    email: '',
    senha: '',
    telefone: '',
    dtNascimento: '',
    funcao: 'Contratante' // função fixa
  };

  erroMsg: string = '';

  constructor(private router: Router, private http: HttpClient) {}

  cadastrar(form: any) {
    this.erroMsg = '';

    // Validar formulário
    if (!form.valid) {
      this.erroMsg = 'Preencha todos os campos corretamente.';
      return;
    }

    // Validação de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.usuario.email)) {
      this.erroMsg = 'Email inválido.';
      return;
    }

    // Validação de senha
    if (this.usuario.senha.length < 8) {
      this.erroMsg = 'A senha deve ter pelo menos 8 caracteres.';
      return;
    }

    // Validação de idade >= 18
    const hoje = new Date();
    const nascimento = new Date(this.usuario.dtNascimento);
    let idade = hoje.getFullYear() - nascimento.getFullYear();
    const m = hoje.getMonth() - nascimento.getMonth();
    if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
      idade--;
    }
    if (idade < 18) {
      this.erroMsg = 'Você deve ter pelo menos 18 anos para se cadastrar.';
      return;
    }

    // Validação de telefone simples (somente números e mínimo 10 dígitos)
    const telefoneRegex = /^\d{10,}$/;
    if (!telefoneRegex.test(this.usuario.telefone.replace(/\D/g, ''))) {
      this.erroMsg = 'Telefone inválido.';
      return;
    }

    // Enviar para a API (frontend-only change)
    const payload = {
      nome: this.usuario.nome,
      email: this.usuario.email,
      senha: this.usuario.senha,
      funcao: 'Contratante',
      dtNascimento: this.usuario.dtNascimento,
      telefone: this.usuario.telefone
    };

    this.http.post<any>('http://localhost:8080/seliganosamba/api/usuarios', payload).subscribe({
      next: (res) => {
        // sucesso: redirecionar para login
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('Erro ao cadastrar', err);
        if (err?.status === 409) {
          this.erroMsg = 'Email já cadastrado.';
        } else if (err?.status === 400) {
          this.erroMsg = 'Dados inválidos. Verifique os campos.';
        } else {
          this.erroMsg = 'Erro ao conectar com o servidor.';
        }
      }
    });
  }
}
