import { Component, OnInit } from '@angular/core';
import { AgendaVisitante } from '../services/agenda-visitante'; 

@Component({
  selector: 'app-agenda-visitante',
  templateUrl: './agenda-visitante.page.html',
  styleUrls: ['./agenda-visitante.page.scss'],
  standalone: false,
})
export class AgendaVisitantePage implements OnInit {

  agendamentos: any[] = [];
  loading = false;
  error: string | null = null;
  selected: any = null; // Added selected property
  // debug removed

  constructor(private agendaService: AgendaVisitante) { }

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading = true;
    this.error = null;

    this.agendaService.getAgendamentos().subscribe({
  next: (data) => {
    // received data

    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0); // Zera horas para comparar apenas data

    const raw = (data || []);

    // logar os tipos recebidos (amostra)
    // types sample logging removed

    // filtra por 'Público' de forma robusta (case + acentos tolerantes)
    const normalize = (s: string) => {
      const t = (s || '').toString().trim().toLowerCase();
      try {
        // remove diacríticos
        let n = t.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        // keep only letters
        n = n.replace(/[^a-zA-Z\u00C0-\u017F]/g, '');
        return n;
      } catch (e) {
        return t.replace(/[^a-zA-Z\u00C0-\u017F]/g, '');
      }
    };

    const isPublico = (a: any) => {
      const tipoNorm = normalize(a.tipoEvento);
      // aceita somente se contiver 'publico' e não contiver 'priv' ou 'private'
      const containsPublico = tipoNorm.indexOf('publico') !== -1;
      const containsPriv = tipoNorm.indexOf('priv') !== -1 || tipoNorm.indexOf('private') !== -1;
      return containsPublico && !containsPriv;
    };

    const publicos = raw.filter((a: any) => {
      const ok = isPublico(a);
      if (!ok) {
        // logar tipos que não são considerados públicos
        // console.debug('excluido por tipo (não-publico):', a.tipoEvento, '->', normalize(a.tipoEvento));
      }
      return ok;
    });

    // removed debug log

    // Expor todos os eventos públicos retornados pela API (sem filtrar por data)
    // Mas ordenados em ordem crescente pela dataEvento (eventos sem data vão ao final)
    const parseLocalDate = (input: any): Date | null => {
      if (input == null) return null;
      if (typeof input === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(input)) {
        const [y, m, d] = input.split('-').map(Number);
        return new Date(y, m - 1, d);
      }
      try {
        const d = new Date(input);
        if (isNaN(d.getTime())) return null;
        return d;
      } catch (e) { return null; }
    };

    const dateForSort = (a: any) => {
      const d = parseLocalDate(a?.dataEvento);
      return d ? d.getTime() : Number.POSITIVE_INFINITY;
    };

    publicos.sort((a: any, b: any) => {
      const ta = dateForSort(a);
      const tb = dateForSort(b);
      return ta - tb;
    });

    // Filtrar eventos com data anterior a hoje (manter eventos sem data)
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const publicosFuturos = publicos.filter((a: any) => {
      const d = parseLocalDate(a?.dataEvento);
      if (!d) return true; // sem data -> manter
      d.setHours(0, 0, 0, 0);
      return d.getTime() >= today.getTime(); // mantém hoje e futuros
    });

    this.agendamentos = publicosFuturos;
    // debug state removed
    this.loading = false;
  },

  error: (err) => {
    console.error('Erro ao carregar agendamentos', err);
    this.error = 'Erro ao carregar agendamentos';
    this.loading = false;
  }
});

   
  }

  openDetails(a: any) {
    this.selected = a;
  }

  closeDetails() {
    this.selected = null;
  }

  getDay(dateString: string): string {
  // parse date-only strings as local date to avoid timezone shift
  if (!dateString) return '';
  const match = typeof dateString === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dateString);
  const d = match ? ((): Date => {
    const [y, m, day] = dateString.split('-').map(Number);
    return new Date(y, m - 1, day);
  })() : new Date(dateString as any);
  return isNaN(d.getTime()) ? '' : d.getDate().toString().padStart(2, '0');
}

getMonth(dateString: string): string {
  // parse date-only strings as local date to avoid timezone shift
  if (!dateString) return '';
  const match = typeof dateString === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dateString);
  const d = match ? ((): Date => {
    const [y, mm, dd] = dateString.split('-').map(Number);
    return new Date(y, mm - 1, dd);
  })() : new Date(dateString as any);
  const m = isNaN(d.getTime()) ? 0 : d.getMonth();
  const meses = ['JANEIRO','FEVEREIRO','MARÇO','ABRIL','MAIO','JUNHO','JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'];
  return meses[m];
}

}
