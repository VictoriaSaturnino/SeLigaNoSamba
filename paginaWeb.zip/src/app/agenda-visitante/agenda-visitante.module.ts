import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AgendaVisitantePageRoutingModule } from './agenda-visitante-routing.module';

import { AgendaVisitantePage } from './agenda-visitante.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AgendaVisitantePageRoutingModule
  ],
  declarations: [AgendaVisitantePage]
})
export class AgendaVisitantePageModule {}
