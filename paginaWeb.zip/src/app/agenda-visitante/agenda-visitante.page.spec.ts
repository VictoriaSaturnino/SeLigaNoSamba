import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AgendaVisitantePage } from './agenda-visitante.page';

describe('AgendaVisitantePage', () => {
  let component: AgendaVisitantePage;
  let fixture: ComponentFixture<AgendaVisitantePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AgendaVisitantePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
