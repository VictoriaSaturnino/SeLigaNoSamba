import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sair',
  templateUrl: './sair.page.html',
  styleUrls: ['./sair.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule]
})
export class SairPage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
    // Clear authentication info and redirect to home
    try {
      localStorage.removeItem('user');
    } catch (e) {
      // ignore
    }
    // small timeout so page can render if needed, then navigate
    setTimeout(() => {
      this.router.navigate(['/home']);
    }, 50);
  }

}
