import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PerfilContratantePage } from './perfil-contratante.page';

describe('PerfilContratantePage', () => {
  let component: PerfilContratantePage;
  let fixture: ComponentFixture<PerfilContratantePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PerfilContratantePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
