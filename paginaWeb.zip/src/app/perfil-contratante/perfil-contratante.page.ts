import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-perfil-contratante',
  templateUrl: './perfil-contratante.page.html',
  styleUrls: ['./perfil-contratante.page.scss'],
  standalone: false,
})
export class PerfilContratantePage implements OnInit {
  usuario: any = { nome: '', email: '', telefone: '', dtNascimento: '', senha: '' };
  saving = false;
  contratosParaAssinar: any[] = [];
  private apiUsuario = 'http://localhost:8080/seliganosamba/api/usuarios';
  private apiContratos = 'http://localhost:8080/seliganosamba/api/contratos';

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit() {
    // Tenta obter usuário salvo no localStorage (feito no login)
      try {
        const raw = localStorage.getItem('user');
        if (raw) {
          const stored = JSON.parse(raw);
          const id = stored.id || stored.idUsuario;
          if (id) {
            this.loadUsuario(id);
            return;
          }
        }
      } catch (e) {
        // ignore
      }
      this.router.navigate(['/login']);
  }

  private loadUsuario(id: number) {
    this.http.get<any>(`${this.apiUsuario}/${id}`).subscribe({
      next: (resp) => {
        this.usuario = {
          idUsuario: resp.idUsuario,
          nome: resp.nome,
          email: resp.email,
          telefone: resp.telefone,
          dtNascimento: resp.dtNascimento ? resp.dtNascimento.toString() : '',
          senha: resp.senha || ''
        };
        this.loadContratosParaAssinar(resp.idUsuario);
      },
      error: () => {
        this.router.navigate(['/login']);
      }
    });
  }

  private loadContratosParaAssinar(idUsuario: number) {
    this.http.get<any[]>(this.apiContratos).subscribe({
      next: (data) => {
        const list = data || [];
        this.contratosParaAssinar = list
          .filter(c => {
            const ag = c.agendamento || {};
            const isMeu = ag.idUsuario === idUsuario;
            const faltaMinhaAssinatura = c.assinaturaContratante !== true && c.assinaturaContratante !== 'true';
            return isMeu && faltaMinhaAssinatura;
          })
          .map(c => {
            const ag = c.agendamento || {};
            return {
              ...c,
              dataEvento: ag.dataEvento,
              cidade: ag.cidade,
              estado: ag.estado
            };
          });
      },
      error: (err) => {
        console.error('Erro carregando contratos para assinar', err);
        this.contratosParaAssinar = [];
      }
    });
  }

  salvarDados() {
    if (!this.usuario?.idUsuario) return;
    this.saving = true;
    const payload = {
      nome: this.usuario.nome,
      email: this.usuario.email,
      telefone: this.usuario.telefone,
      dtNascimento: this.usuario.dtNascimento,
      funcao: 'contratante',
      senha: this.usuario.senha || ''
    };
    this.http.put(`${this.apiUsuario}/${this.usuario.idUsuario}`, payload).subscribe({
      next: () => alert('Dados atualizados com sucesso.'),
      error: () => alert('Erro ao salvar dados.')
    }).add(() => this.saving = false);
  }

  getDay(dateStr: string) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? '' : d.getDate();
  }

  getMonthShort(dateStr: string) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? '' : d.toLocaleString('pt-BR', { month: 'short' }).toUpperCase();
  }

}
