import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PerfilContratantePage } from './perfil-contratante.page';

const routes: Routes = [
  {
    path: '',
    component: PerfilContratantePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PerfilContratantePageRoutingModule {}
