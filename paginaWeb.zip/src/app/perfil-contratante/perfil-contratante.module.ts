import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';

import { PerfilContratantePageRoutingModule } from './perfil-contratante-routing.module';

import { PerfilContratantePage } from './perfil-contratante.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    PerfilContratantePageRoutingModule
  ],
  declarations: [PerfilContratantePage]
})
export class PerfilContratantePageModule {}
